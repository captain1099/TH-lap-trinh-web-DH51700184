<?php
$servername = "localhost:3308";
$database = "linhkien";
$username = "root";
$password = "";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
$conn->set_charset("utf8");

?>